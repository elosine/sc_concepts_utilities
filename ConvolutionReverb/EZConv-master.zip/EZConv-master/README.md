#EZConv
A convenience wrapper class around PartConv.
See the documentation for more info and examples.
